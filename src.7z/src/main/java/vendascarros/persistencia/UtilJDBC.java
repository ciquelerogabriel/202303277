package vendascarros.persistencia;

public class UtilJDBC {
	static final String url =
			//jdbc:banco:ip_servidor:porta/database
			"jdbc:postgresql://127.0.0.1:5432/vendascarros";
	static final String usuario = "postgres";
	static final String senha = "aluno";

	public static Connection getConnection() throws Exception
	{
		Connection con = null;
		try {
			Class.forName("org.postgresql.Driver");
			System.out.println("JDBC Driver Ok");
			con = DriverManager.getConnection(url,usuario,senha);
			if (con != null) {
				System.out.println("Conexão Ok");
				return con;
			} else {
				throw new Exception("A conexão não foi criada!"); }
		} catch (ClassNotFoundException e) {
			System.out.println("Driver JDBC inválido");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("Falha na conexão");
			e.printStackTrace();
		}
		return con;
	} 
}
