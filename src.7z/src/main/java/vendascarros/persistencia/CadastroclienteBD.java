package vendascarros.persistencia;

public class CadastroclienteBD {

	public boolean inserir(Carro pedido) throws Exception {
		boolean retorno = false;
		//comentario
		PreparedStatement stmt = null;
		Connection con = null;
		String sql = "insert into Usuario(nmUsuario, deEmail, deSenha) values (?, ?, ?)";

		try {
			con = UtilJDBC.getConnection();
			stmt = con.prepareStatement(sql);
			stmt.setString(1, usuario.getNome());
			stmt.setString(2, usuario.getEmail());
			stmt.setString(3, usuario.getSenha());
			stmt.executeUpdate();
			retorno = true;
		} catch (Exception e ) {
			System.out.println(e);
		} finally {
			if (stmt != null) { 
				stmt.close(); 
			}
			if (con != null) { 
				con.close();
			}
		}
		return retorno; }

}
