package vendascarros.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import vendascarros.Carro;


@WebServlet("/cadvenda")
public class ServletCadVenda extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		//preparando o response
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();


		//recuperei os dados do formulário HTML pelo objeto request
		//instanciando objeto da classe Carro
		Carro carro = new Carro();
		//definindo o estado do objeto pelos métodos
		if (!carro.setNomeComprador(request.getParameter("nome"))) {
			//registra erro do nome num vetor
			pw.println ("Nome inválido");
		}
		carro.setCpfComprador(request.getParameter("cpf"));
		carro.setContatoComprador(request.getParameter("contato"));
		carro.setMarcaCarro(request.getParameter("marca"));;
		carro.setModeloCarro(request.getParameter("modelo"));
		carro.setAnoCarro(Integer.valueOf(request.getParameter("ano")));
		carro.setPlacaCarro(request.getParameter("placa"));
		carro.setValorCarro(Integer.valueOf(request.getParameter("valor")));
		carro.setDataCarro(request.getParameter("Data"));;
		carro.setGarantiaCarro(request.getParameter("garantia"));
		//objeto de negócio já está preenchido com os dados do form HTML
		//instanciar camada de banco de dados

		/*
		//Gerar uma resposta HTML pelo 
		resp.setContentType("text/HTML");
		PrintWriter pw = resp.getWriter();
		pq.prinln("<ch1> Nome = "+ sNome + " </ch1>");
		 */
	}

}
