package vendascarros;

public class Carro {

	//atributos cliente
	private String nomeComprador;
	private String cpfComprador;
	private String contatoComprador;


	//atributos carro
	private String marcaCarro;
	private String modeloCarro;
	private int anoCarro;
	private String placaCarro;
	private double valorCarro;
	private String dataCarro;
	private String garantiaCarro;


	//construtor
	public Carro() {
		this.nomeComprador = "";
		this.cpfComprador = "000.000.000-00";
		this.contatoComprador = "+55";

		this.dataCarro = "00/00/0000";
		this.marcaCarro = "";
		this.modeloCarro = "";
		this.anoCarro = 0000;
		this.placaCarro = "";
		this.valorCarro = 0;
		this.dataCarro = "00/00/0000";
		this.garantiaCarro = "";
	}


	//metodo
	public String getNomeComprador () {
		return this.nomeComprador;
	}
	public boolean setNomeComprador (String nome) {
		boolean valido = false;
		if (nome.matches("[a-zA-Z]+") && (nome.length() > 5)) {
			this.nomeComprador = nome;
			valido = true;
		}else {
			this.nomeComprador = "Anônimo";
		}
		return valido;
	}



	public String getCpfComprador () {
		return this.cpfComprador;
	}
	public boolean setCpfComprador (String cpf) {
		boolean valido = false;
		if (cpf.length() == 11) {
			this.cpfComprador = cpf;
			valido = true;
		}else {
			this.cpfComprador = "Inválido";
		}
		return valido;
	}



	public String getContatoComprador () {
		return this.contatoComprador;
	}
	public boolean setContatoComprador (String contato) {
		boolean valido = false;
		if (contato.length() == 14) {
			this.contatoComprador = contato;
			valido = true;
		}else {
			this.contatoComprador = "Inválido";
		}
		return valido;
	}



	public String getMarcaCarro () {
		return this.marcaCarro;
	}
	public void setMarcaCarro (String marca) {
		this.marcaCarro = marca;
	}



	public String getModeloCarro () {
		return this.modeloCarro;
	}
	public void setModeloCarro (String modelo) {
		this.modeloCarro = modelo;
	}



	public int getAnoCarro () {
		return this.anoCarro;
	}
	public boolean setAnoCarro (int ano) {
		boolean valido = false;
		if (ano > 1000) {
			this.anoCarro = ano;
			valido = true;
		}else {
			this.anoCarro = 0000;
		}
		return valido;
	}



	public String getPlacaCarro () {
		return this.placaCarro;
	}
	public boolean setPlacaCarro (String placa) {
		boolean valido = false;
		if (placa.length() == 7) {
			this.placaCarro = placa;
			valido = true;
		}else {
			this.placaCarro = "Inválido";
		}
		return valido;
	}



	public double getValorCarro () {
		return this.valorCarro;
	}
	public boolean setValorCarro (double valor) {
		boolean valido = false;
		if (valor < 0) {
			this.valorCarro = valor;
			valido = true;
		}else {
			this.valorCarro = 0;
		}
		return valido;
	}



	public String getDataCarro () {
		return this.dataCarro;
	}
	public void setDataCarro (String data) {
		this.dataCarro = data;
	}



	public String getGarantiaCarro () {
		return this.garantiaCarro;
	}
	public void setGarantiaCarro (String garantia) {
		this.garantiaCarro = garantia;
	}
}
